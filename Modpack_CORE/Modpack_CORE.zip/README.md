# ZenMod Core Collection

This modpack contains all of the ZenMods in a single core collection.

---
#### Like My Mods? Donations Welcome

`Bitcoin: bc1q34lrc82dp73jhv9ylefz0gvmeqfn96e938p4pf`

<img alt="Donation QR" src="https://github.com/ZenDragonX/ZenMods_Valheim/blob/main/BTC_QR.png?raw=true" width=180>
